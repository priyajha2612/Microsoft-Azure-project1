You can read more on the accompanying blogpost: https://aidensgallyvanting.blogspot.com/2020/02/pattern-matching-chatbots-how-they-work.html 

# chatbotExamples
example of pattern matching chatbots